package com.itlike.view.adminview;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Book;
import com.itlike.domain.Student;
import com.itlike.mapper.AdminMapper;
import com.itlike.utils.MybatisUtils;
import com.itlike.view.AdminMenuView;

public class DoUpdateBookView extends JFrame implements ActionListener {
	JPanel jp1,jp2,jp3;
	JLabel jlb1,jlb2;
	JTextField jtf1,jtf2;
	JButton jb1,jb2,jb3;
    
    public DoUpdateBookView() {
    	jp1 = new JPanel();
        jp2 = new JPanel();
        jp3 = new JPanel();
        
        jlb1 = new JLabel("���");
		jlb2 = new JLabel("����");
		
		jtf1 = new JTextField(20);
		jtf2 = new JTextField(20);
		
		jb1 = new JButton("����");
		jb2 = new JButton("����");
		jb3 = new JButton("����");
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		this.setLayout(new GridLayout(3,1));
		
		jp1.add(jlb1);
		jp1.add(jtf1);
		
		jp2.add(jlb2);
		jp2.add(jtf2);
		
		jp3.add(jb1);
		jp3.add(jb2);
		jp3.add(jb3);
		
		this.add(jp1);
        this.add(jp2);
        this.add(jp3);
        
        this.setSize(400, 240);
		this.setLocation(750,400);
        this.setTitle("�޸�ͼ��");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "����") {
			clear();
		}else if(e.getActionCommand() == "����") {
			dispose();
			new AdminMenuView();
		}else if(e.getActionCommand() == "����") {
			if(jtf1.getText() == null || jtf2.getText() == null){
				JOptionPane.showMessageDialog(null, "������������Ϣ");
			}else {
				SqlSession openSession = MybatisUtils.openSession();
				AdminMapper mapper = openSession.getMapper(AdminMapper.class);
				Book book = new Book();
				book.setB_id(Long.parseLong(jtf1.getText()));
				book.setB_name(jtf2.getText());
				mapper.updateBook(book);
				openSession.commit();
				openSession.close();
				JOptionPane.showMessageDialog(null, "���³ɹ�");
				dispose();
				new AdminMenuView();
			}
		}
	}
	public void clear() {
		jtf1.setText("");
		jtf2.setText("");
	}
	
}
