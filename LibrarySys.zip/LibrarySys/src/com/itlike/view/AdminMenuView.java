package com.itlike.view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.itlike.Controller.MyWindowEventHandle;
import com.itlike.utils.MyUtils;
import com.itlike.view.adminview.DoDeleteBookView;
import com.itlike.view.adminview.DoDeleteStuView;
import com.itlike.view.adminview.DoInsertBookView;
import com.itlike.view.adminview.DoInsertStuView;
import com.itlike.view.adminview.DoUpdateBookView;
import com.itlike.view.adminview.DoUpdateStuView;
import com.itlike.view.adminview.SelectBorrow;

public class AdminMenuView extends JFrame implements ActionListener{
	JPanel pan1 = new JPanel();
	JPanel pan2 = new JPanel();
	JPanel pan3 = new JPanel();
	JPanel pan4 = new JPanel();
	JPanel pan5 = new JPanel();
	JButton jb1,jb2,jb3,jb4,jb5,jb6,jb7,jb8;
	JTabbedPane tab;
	
	
	public AdminMenuView() {	
		
		jb1 = new JButton("���Ӷ�����Ϣ");
		jb2 = new JButton("ɾ��������Ϣ");
		jb3 = new JButton("�޸Ķ�����Ϣ");
		jb4 = new JButton("����ͼ����Ϣ");
		jb5 = new JButton("ɾ��ͼ����Ϣ");
		jb6 = new JButton("�޸�ͼ����Ϣ");
		jb7 = new JButton("���Ĳ�ѯ");
		jb8 = new JButton("����ͳ��");
		
		this.setLayout(new GridLayout(4,1));
		
		pan1.add(jb1);
		pan1.add(jb4);
		pan2.add(jb2);
		pan2.add(jb5);
		pan3.add(jb3);
		pan3.add(jb6);
		pan4.add(jb7);
		pan4.add(jb8);
		
		this.add(pan1);
		this.add(pan2);
		this.add(pan3);
		this.add(pan4);
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		jb4.addActionListener(this);
		jb5.addActionListener(this);
		jb6.addActionListener(this);
		jb7.addActionListener(this);
		jb8.addActionListener(this);
		
		this.setSize(500, 300);
		this.setLocation(750,400);
        this.setTitle("AdminMenu");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "���Ӷ�����Ϣ") {
			dispose();
			new DoInsertStuView();
		}
		if(e.getActionCommand() == "ɾ��������Ϣ") {
			dispose();
			new DoDeleteStuView();
		}
		if(e.getActionCommand() == "�޸Ķ�����Ϣ") {
			dispose();
			new DoUpdateStuView();
		}
		if(e.getActionCommand() == "����ͼ����Ϣ") {
			dispose();
			new DoInsertBookView();
		}
		if(e.getActionCommand() == "ɾ��ͼ����Ϣ") {
			dispose();
			new DoDeleteBookView();
		}
		if(e.getActionCommand() == "�޸�ͼ����Ϣ") {
			dispose();
			new DoUpdateBookView();
		}
		if(e.getActionCommand() == "���Ĳ�ѯ") {
			dispose();
			new SelectBorrow();
		}
		if(e.getActionCommand() == "����ͳ��") {
			MyUtils myUtils = new MyUtils();
			Long b_count = myUtils.selectBorrowCount();
			Long count = myUtils.selectAllCount();
			JOptionPane.showMessageDialog(null, "��"+count+"��ͼ�飬�ѱ����ĳ�ȥ"+b_count+"��");
		}
		
	}
	public static void main(String[] args) {
		new AdminMenuView().addWindowListener(new MyWindowEventHandle());
	}
}
