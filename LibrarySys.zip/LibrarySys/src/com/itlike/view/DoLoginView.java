package com.itlike.view;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Admin;
import com.itlike.domain.Student;
import com.itlike.mapper.AdminMapper;
import com.itlike.mapper.StudentMapper;
import com.itlike.utils.MybatisUtils;


public class DoLoginView extends JFrame implements ActionListener,ItemListener{
	JPanel jp1, jp2, jp3,jp4;
    JLabel jlb1, jlb2;
    JButton jb1, jb2;
    JTextField jtf1;
    JPasswordField jpf1;
    JRadioButton jrb1,jrb2;
    String role = null;
    
    
    public DoLoginView(){
    	jp1 = new JPanel();
        jp2 = new JPanel();
        jp3 = new JPanel();
        jp4 = new JPanel();

        jlb1 = new JLabel("�û���");
        jlb2 = new JLabel("��    ��");

        jb1 = new JButton("��¼");
        jb2 = new JButton("ȡ��");
        
        jb1.addActionListener(this);
        jb2.addActionListener(this);

        jtf1 = new JTextField(10);

        jpf1 = new JPasswordField(10);
        this.setLayout(new GridLayout(4, 1));
        
        jrb1 = new JRadioButton("student");
        jrb1.addItemListener(this);
        jrb2 = new JRadioButton("teacher");
        jrb2.addItemListener(this);

        // ����������
        jp1.add(jlb1);
        jp1.add(jtf1);
        jp2.add(jlb2);
        jp2.add(jpf1);
        jp4.add(jb1);
        jp4.add(jb2);
        jp3.add(jrb1);
        jp3.add(jrb2);

        // ���뵽JFrame
        this.add(jp1);
        this.add(jp2);
        this.add(jp3);
        this.add(jp4);

        this.setSize(400, 240);
        this.setLocation(750,400);
        this.setTitle("���¼");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "ȡ��") {
			clear();
		}
		else if(e.getActionCommand() == "��¼") {
			userLogin();
		}
		
	}
	public void userLogin() {
		SqlSession openSession = MybatisUtils.openSession();
		Student student = null;
		Admin admin = null;
		if(role == "student") {
			StudentMapper mapper = openSession.getMapper(StudentMapper.class);
			student = mapper.getStudentByLogin(jtf1.getText(), jpf1.getText());
		}
		else if(role == "admin") {
			AdminMapper mapper = openSession.getMapper(AdminMapper.class);
			admin = mapper.getAdminByLogin(jtf1.getText(), jpf1.getText());
		}
		
		if(student != null) {
			System.out.println("ѧ����¼�ɹ�");
			JOptionPane.showMessageDialog(null, "Login finish!");
			dispose();
			new StuMenuView(student);
		}
		else if(admin != null) {
			System.out.println("����Ա��¼�ɹ�");
			JOptionPane.showMessageDialog(null, "Login finish!");
			dispose();
			new AdminMenuView();
		}
		else {
			JOptionPane.showMessageDialog(null,"�û������������������������ȷ���û���������!");
			clear();
		}
		openSession.close();
		
	}
	
	public void clear() {
    	jtf1.setText("");
    	jpf1.setText("");
    }

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource() == jrb1) {
			this.role = "student";
			System.out.println(this.role);
		}else if(e.getSource() == jrb2) {
			this.role = "admin";
			System.out.println(this.role);
		}
	}
	public static void main(String[] args) {
		new DoLoginView();
	}
	
	
}
