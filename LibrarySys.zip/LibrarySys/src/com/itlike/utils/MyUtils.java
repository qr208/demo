package com.itlike.utils;

import org.apache.ibatis.session.SqlSession;

import com.itlike.mapper.AdminMapper;

public class MyUtils {
	public Long selectBorrowCount() {
		SqlSession openSession = MybatisUtils.openSession();
		AdminMapper mapper = openSession.getMapper(AdminMapper.class);
		Long count = mapper.selectBorrowCount();
		openSession.close();
		return count;
	}
	
	public Long selectAllCount() {
		SqlSession openSession = MybatisUtils.openSession();
		AdminMapper mapper = openSession.getMapper(AdminMapper.class);
		Long countBooks = mapper.selectAllCountBooks();
		openSession.close();
		return countBooks;
	}
}
