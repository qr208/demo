package com.itlike.view.stuview;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Book;
import com.itlike.domain.Student;
import com.itlike.mapper.StudentMapper;
import com.itlike.utils.MybatisUtils;
import com.itlike.view.StuMenuView;

public class DoBorrowBookView extends JFrame implements ActionListener {
	Student student;
	Long b_id = null;
	DefaultTableModel tabelmodel = null;
	JTable table;
	JScrollPane scr;
	String[] title = {"���","����"};
	Object[][] data = null;
	JPanel jp1,jp2,jp3;
	JLabel jlb1,jlb2;
	JTextField jtf1,jtf2;
	JButton jb1,jb2,jb3,jb4;
	
	public DoBorrowBookView(Student student) {
		this.student = student;
		
		jp1 = new JPanel();
        jp2 = new JPanel();
        jp3 = new JPanel();
        
        jlb1 = new JLabel("���");
        jlb2 = new JLabel("����");
        
        jtf1 = new JTextField(20);
        jtf2 = new JTextField(20);
        
        jb1 = new JButton("��ѯ");
		jb2 = new JButton("����");
		jb3 = new JButton("����");
		jb4 = new JButton("����");
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		jb4.addActionListener(this);
		
		this.tabelmodel = new DefaultTableModel(this.data,this.title);
		table = new JTable(this.tabelmodel);
		scr = new JScrollPane(table);
		
		this.setLayout(new GridLayout(4, 1));
		
		jp1.add(jlb1);
		jp1.add(jtf1);
		
		jp2.add(jlb2);
		jp2.add(jtf2);
		
		jp3.add(jb1);
		jp3.add(jb2);
		jp3.add(jb3);
		jp3.add(jb4);
		
		this.add(jp1);
		this.add(jp2);
		this.add(jp3);
        this.add(scr);
        
        this.setSize(400, 300);
        this.setLocation(750,400);
        this.setTitle("����");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "����") {
			new DoSelectBookView(this.student);
		}
		else if(e.getActionCommand() == "����") {
			dispose();
			new StuMenuView(this.student);
		}
		else if(e.getActionCommand() == "��ѯ") {
			SqlSession openSession = MybatisUtils.openSession();
			StudentMapper mapper = openSession.getMapper(StudentMapper.class);
			List<Book> list = new ArrayList();
			Book book = new Book();
			if(jtf1.getText() != null && !"".equals(jtf1.getText())) {
				book.setB_id(Long.parseLong(jtf1.getText()));
			}else {
				book.setB_id(null);
			}
			book.setB_name(jtf2.getText());
			list = mapper.selectBooksByStu(book);
			if(list.size() == 1) {
				b_id = list.get(0).getB_id();
			}
			Iterator it = list.iterator();
			while(it.hasNext()) {
				Book book1 = (Book)it.next();
				Object[] obj = {book1.getB_id(),book1.getB_name()};
				this.tabelmodel.addRow(obj);
			}
			openSession.close();
		}
		if(e.getActionCommand() == "����") {
			if(b_id == null) {
				JOptionPane.showMessageDialog(null, "�����һ�����н���");
			}else{
				Long s_id = this.student.getS_id();
				SqlSession openSession = MybatisUtils.openSession();
				StudentMapper mapper = openSession.getMapper(StudentMapper.class);
				Book bookById = mapper.selectBookById(b_id);
				if(bookById.getBorrow_id() != null && bookById.getBorrow_id() != 0) {
					JOptionPane.showMessageDialog(null, "�����ѱ����ģ�����������鼮");
				}else {
					mapper.borrowBook(b_id, s_id);
					openSession.commit();
					JOptionPane.showMessageDialog(null, "���ĳɹ�");
					dispose();
					new StuMenuView(this.student);
				}
				openSession.close();
			}
		}
	}
}
