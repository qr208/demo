package com.itlike.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter@Getter@ToString
public class Book {
	private Long b_id;
	private String b_name;
	private Long borrow_id;
}
