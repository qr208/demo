package com.itlike.view.stuview;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Book;
import com.itlike.domain.Student;
import com.itlike.mapper.StudentMapper;
import com.itlike.utils.MybatisUtils;
import com.itlike.view.StuMenuView;

public class DoSelectBorrowView extends JFrame implements ActionListener {
	Student student;
	DefaultTableModel tabelmodel = null;
	JTable table;
	JScrollPane scr;
	String[] title = {"���","����"};
	Object[][] data = null;
	JPanel jp1;
	JButton jb1,jb2,jb3;
	
	public DoSelectBorrowView(Student student) {
		this.student = student;
		
		jp1 = new JPanel();
        
        jb1 = new JButton("��ѯ");
        jb2 = new JButton("ˢ��");
        jb3 = new JButton("����");
        
        jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
        
        this.tabelmodel = new DefaultTableModel(this.data,this.title);
		table = new JTable(this.tabelmodel);
		scr = new JScrollPane(table);
		
		this.setLayout(new GridLayout(4, 1));
		
		jp1.add(jb1);
		jp1.add(jb2);
		jp1.add(jb3);
		
		this.add(jp1);
        this.add(scr);
        
        this.setSize(400, 300);
        this.setLocation(750,400);
        this.setTitle("�黹");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "ˢ��") {
			new DoSelectBorrowView(this.student);
		}
		else if(e.getActionCommand() == "����") {
			dispose();
			new StuMenuView(this.student);
		}
		else if(e.getActionCommand() == "��ѯ") {
			SqlSession openSession = MybatisUtils.openSession();
			StudentMapper mapper = openSession.getMapper(StudentMapper.class);
			List<Book> list = new ArrayList();
			Book book = new Book();
			list = mapper.selectBorrowBooks(this.student.getS_id(),null);
			Iterator it = list.iterator();
			while(it.hasNext()) {
				Book book1 = (Book)it.next();
				Object[] obj = {book1.getB_id(),book1.getB_name()};
				this.tabelmodel.addRow(obj);
			}
			openSession.close();
		}
	}
	
	
	
	
	
	
}
