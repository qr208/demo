package com.itlike.test;

import com.itlike.Controller.MyWindowEventHandle;
import com.itlike.view.DoLoginView;

public class testMain {
	public static void main(String[] args) {
		new DoLoginView().addWindowListener(new MyWindowEventHandle());
	}
}
