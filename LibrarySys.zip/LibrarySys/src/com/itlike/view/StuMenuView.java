package com.itlike.view;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.itlike.Controller.MyWindowEventHandle;
import com.itlike.domain.Student;
import com.itlike.view.stuview.DoBorrowBookView;
import com.itlike.view.stuview.DoReturnBookView;
import com.itlike.view.stuview.DoSelectBookView;
import com.itlike.view.stuview.DoSelectBorrowView;
import com.itlike.view.stuview.UpdatePassView;

public class StuMenuView extends JFrame implements ActionListener{
	JPanel pan1 = new JPanel();
	JPanel pan2 = new JPanel();
	JPanel pan3 = new JPanel();
	JPanel pan4 = new JPanel();
	JPanel pan5 = new JPanel();
	JButton jb1,jb2,jb3,jb4,jb5;
	JTabbedPane tab;
	Student student;
	
	public StuMenuView(Student student) {	
		
		jb1 = new JButton("��ѯͼ��");
		jb2 = new JButton("����ͼ��");
		jb3 = new JButton("�黹ͼ��");
		jb4 = new JButton("��ѯ���ļ�¼");
		jb5 = new JButton("�޸�����");
		this.student = student;
		this.setLayout(new GridLayout(5,1));
		
		pan1.add(jb1);
		pan2.add(jb2);
		pan3.add(jb3);
		pan4.add(jb4);
		pan5.add(jb5);
		
		this.add(pan1);
		this.add(pan2);
		this.add(pan3);
		this.add(pan4);
		this.add(pan5);
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		jb4.addActionListener(this);
		jb5.addActionListener(this);
		
		this.setSize(500, 300);
		this.setLocation(750,400);
        this.setTitle("Menu");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "��ѯͼ��") {
			dispose();
			new DoSelectBookView(student);
		}
		if(e.getActionCommand() == "����ͼ��") {
			dispose();
			new DoBorrowBookView(student);
		}
		if(e.getActionCommand() == "�黹ͼ��") {
			dispose();
			new DoReturnBookView(student);
		}
		if(e.getActionCommand() == "��ѯ���ļ�¼") {
			dispose();
			new DoSelectBorrowView(student);
		}
		if(e.getActionCommand() == "�޸�����") {
			dispose();
			new UpdatePassView(student);
		}
		
	}
	

}
