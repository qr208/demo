package com.itlike.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter@Getter@ToString
public class Student {
	private Long s_id;
	private String s_name;
	private String s_gender;
	private Integer s_age;
	private String password;
}
