package com.itlike.view.stuview;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Student;
import com.itlike.mapper.StudentMapper;
import com.itlike.utils.MybatisUtils;
import com.itlike.view.DoLoginView;
import com.itlike.view.StuMenuView;

public class UpdatePassView extends JFrame implements ActionListener {
	Student student = null;
	JPanel jp1, jp2, jp3;
    JLabel jlb1, jlb2;
    JButton jb1, jb2, jb3;
    JPasswordField jpf1,jpf2;
    JRadioButton jrb1,jrb2;
    
    public UpdatePassView(Student student) {
		this.student = student;
		
		jp1 = new JPanel();
        jp2 = new JPanel();
        jp3 = new JPanel();
        
        jb1 = new JButton("�޸�");
        jb2 = new JButton("���");
        jb3 = new JButton("����");
        
        jb1.addActionListener(this);
        jb2.addActionListener(this);
        jb3.addActionListener(this);
        
        jlb1 = new JLabel("ԭ  ��  ��  ��");
        jlb2 = new JLabel("�޸ĺ������");
        
        jpf1 = new JPasswordField(10);
        jpf2 = new JPasswordField(10);
        
        this.setLayout(new GridLayout(3, 1));
        
        jp1.add(jlb1);
        jp1.add(jpf1);
        jp2.add(jlb2);
        jp2.add(jpf2);
        jp3.add(jb1);
        jp3.add(jb2);
        jp3.add(jb3);
        
        this.add(jp1);
        this.add(jp2);
        this.add(jp3);
        
        this.setSize(400, 240);
        this.setLocation(750,400);
        this.setTitle("�޸�����");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
    
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "���") {
			clear();
		}
		else if(e.getActionCommand() == "����") {
			new StuMenuView(this.student);
		}
		else if(e.getActionCommand() == "�޸�") {
			updatePass();
		}
	}
	
	public void updatePass() {
		
		if(jpf2.getText() == null || "".equals(jpf2.getText())) {
			JOptionPane.showMessageDialog(null,"�������޸ĺ������");
		}
		else if(jpf1.getText().equals(this.student.getPassword())) {
			SqlSession openSession = MybatisUtils.openSession();
			StudentMapper mapper = openSession.getMapper(StudentMapper.class);
			mapper.updatePassword(this.student.getS_id(), jpf2.getText());
			openSession.commit();
			openSession.close();
			JOptionPane.showMessageDialog(null,"�޸ĳɹ��������µ�¼");
			dispose();
			new DoLoginView();
		}else {
			JOptionPane.showMessageDialog(null,"���벻��ȷ���������");
		}
		
	}
	
	public void clear() {
		jpf2.setText("");
    	jpf1.setText("");
    }
    
}
