package com.itlike.utils;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisUtils {
	
	public static final SqlSessionFactory sessionFactory;
	static {
		// 1.SqlSessionFactoryBuilder ���������ļ�
		SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
		// 2.��ȡ�����ļ�
		InputStream resourceAsStream = null;
		try {
			resourceAsStream = Resources.getResourceAsStream("SqlMappingConfig.xml");
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		// 3.��ȡsession����
		sessionFactory = sqlSessionFactoryBuilder.build(resourceAsStream);
	}
	
	public static SqlSession openSession() {
		return sessionFactory.openSession();
	}
	
	
	
}
