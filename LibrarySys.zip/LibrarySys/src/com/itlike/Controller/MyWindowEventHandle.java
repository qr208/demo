package com.itlike.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.sound.midi.SysexMessage;

import com.itlike.view.*;

public class MyWindowEventHandle implements WindowListener{
	public void windowActivated(WindowEvent arg0) {
		System.out.println("windowActivated -> ���ڱ�ѡ��");
	}
	public void windowClosed(WindowEvent arg0) {
		System.out.println("windowActivated -> ���ڱ��ر�");
	}
	public void windowClosing(WindowEvent arg0) {
		System.out.println("windowActivated -> ���ڹر�");
		System.exit(1);
	}
	public void windowDeactivated(WindowEvent arg0) {
		System.out.println("windowActivated -> ȡ������ѡ��");
	}
	public void windowDeiconified(WindowEvent arg0) {
		System.out.println("windowActivated -> ���ڴ���С���ָ�");
	}
	public void windowOpened(WindowEvent arg0) {
		System.out.println("windowActivated -> ���ڱ���");
	}
	public void windowIconified(WindowEvent arg0) {
		System.out.println("windowActivated -> ������С��");
	}
	
	
	
	
	
}
