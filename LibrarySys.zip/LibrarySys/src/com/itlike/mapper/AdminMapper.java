package com.itlike.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.itlike.domain.Admin;
import com.itlike.domain.Book;
import com.itlike.domain.Student;

public interface AdminMapper {
	public Admin getAdminByLogin(@Param("username") String username,@Param("password") String password);
	
	public void insertStu(Student student);
	
	public void updateStu(Student student);
	
	public void deleteStu(Long id);
	
	public void insertBook(Book book);
	
	public void deleteBook(Long id);
	
	public void updateBook(Book book);
	
	public List<Book> selectBooks(Book book);
	
	public Long selectBorrowCount();
	
	public Long selectAllCountBooks();
}
