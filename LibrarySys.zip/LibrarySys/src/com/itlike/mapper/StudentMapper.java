package com.itlike.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.itlike.domain.Book;
import com.itlike.domain.Student;

public interface StudentMapper {
	
	public void insertStudent(Student student);
	public Student getStudentByLogin(@Param("username") String username,@Param("password") String password);
	
	public List<Book> selectBooksByStu(Book book);
	
	public Book selectBookById(Long id);
	
	public void borrowBook(@Param("b_id") Long b_id,@Param("s_id") Long s_id);
	
	public List<Book> selectBorrowBooks(@Param("s_id") Long s_id,@Param("b_name") String b_name);
	
	public void returnBook(Long b_id);
	
	public void updatePassword(@Param("s_id") Long s_id,@Param("password") String password);
}
