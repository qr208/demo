package com.itlike.view.adminview;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.ibatis.session.SqlSession;

import com.itlike.domain.Student;
import com.itlike.mapper.AdminMapper;
import com.itlike.utils.MybatisUtils;
import com.itlike.view.AdminMenuView;

public class DoUpdateStuView extends JFrame implements ActionListener{

	JPanel jp1,jp2,jp3,jp4,jp5,jp6;
	JLabel jlb1,jlb2,jlb3,jlb4,jlb5;
	JTextField jtf1,jtf2,jtf3,jtf4,jtf5;
	JButton jb1,jb2,jb3;
	
	public DoUpdateStuView() {
		jp1 = new JPanel();
        jp2 = new JPanel();
        jp3 = new JPanel();
        jp4 = new JPanel();
        jp5 = new JPanel();
        jp6 = new JPanel();
		
		jlb1 = new JLabel("ѧ��");
		jlb2 = new JLabel("����");
		jlb3 = new JLabel("�Ա�");
		jlb4 = new JLabel("����");
		jlb5 = new JLabel("����");
		
		jtf1 = new JTextField(20);
		jtf2 = new JTextField(20);
		jtf3 = new JTextField(20);
		jtf4 = new JTextField(20);
		jtf5 = new JTextField(20);
		
		jb1 = new JButton("����");
		jb2 = new JButton("����");
		jb3 = new JButton("����");
		
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		jb3.addActionListener(this);
		this.setLayout(new GridLayout(6,1));
		
		jp1.add(jlb1);
		jp1.add(jtf1);
		
		jp2.add(jlb2);
		jp2.add(jtf2);
		
		jp3.add(jlb3);
		jp3.add(jtf3);
		
		jp4.add(jlb4);
		jp4.add(jtf4);
		
		jp5.add(jlb5);
		jp5.add(jtf5);
		
		jp6.add(jb1);
		jp6.add(jb2);
		jp6.add(jb3);
		
		this.add(jp1);
        this.add(jp2);
        this.add(jp3);
		this.add(jp4);
		this.add(jp5);
		this.add(jp6);
		
		this.setSize(400, 240);
		this.setLocation(750,400);
        this.setTitle("�޸Ķ���");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand() == "����") {
			clear();
		}else if(e.getActionCommand() == "����") {
			dispose();
			new AdminMenuView();
		}else if(e.getActionCommand() == "����") {
			if(jtf1.getText() == null || jtf2.getText() == null || jtf3.getText() == null || jtf4.getText() == null || jtf5.getText() == null){
				JOptionPane.showMessageDialog(null, "������������Ϣ");
			}else {
				SqlSession openSession = MybatisUtils.openSession();
				AdminMapper mapper = openSession.getMapper(AdminMapper.class);
				Student student = new Student();
				student.setS_id(Long.parseLong(jtf1.getText()));
				student.setS_name(jtf2.getText());
				student.setS_gender(jtf3.getText());
				student.setS_age(Integer.parseInt(jtf4.getText()));
				student.setPassword(jtf5.getText());
				mapper.updateStu(student);
				openSession.commit();
				openSession.close();
				JOptionPane.showMessageDialog(null, "���³ɹ�");
				dispose();
				new AdminMenuView();
			}
		}
	}
	public void clear() {
		jtf1.setText("");
		jtf2.setText("");
		jtf3.setText("");
		jtf4.setText("");
		jtf5.setText("");
	}
	
	
	
}
